import os

css_content = """
/* Quill Dark Mode Overrides */
[data-theme="dark"] .ql-toolbar.ql-snow {
    border-color: var(--border-color);
    background-color: var(--card-bg);
}
[data-theme="dark"] .ql-container.ql-snow {
    border-color: var(--border-color);
    background-color: var(--input-bg);
    color: var(--text-color);
}
[data-theme="dark"] .ql-snow .ql-stroke {
    stroke: var(--text-muted);
}
[data-theme="dark"] .ql-snow .ql-fill, 
[data-theme="dark"] .ql-snow .ql-stroke.ql-fill {
    fill: var(--text-muted);
}
[data-theme="dark"] .ql-snow .ql-picker {
    color: var(--text-muted);
}
[data-theme="dark"] .ql-snow .ql-picker-options {
    background-color: var(--card-bg);
    border-color: var(--border-color);
}
[data-theme="dark"] .ql-snow .ql-picker-item:hover,
[data-theme="dark"] .ql-snow .ql-picker-label:hover {
    color: var(--text-color);
}
[data-theme="dark"] .ql-snow.ql-toolbar button:hover .ql-stroke,
[data-theme="dark"] .ql-snow .ql-toolbar button:hover .ql-stroke,
[data-theme="dark"] .ql-snow.ql-toolbar button.ql-active .ql-stroke,
[data-theme="dark"] .ql-snow .ql-toolbar button.ql-active .ql-stroke {
    stroke: var(--text-color);
}
[data-theme="dark"] .ql-snow.ql-toolbar button:hover .ql-fill,
[data-theme="dark"] .ql-snow .ql-toolbar button:hover .ql-fill,
[data-theme="dark"] .ql-snow.ql-toolbar button.ql-active .ql-fill,
[data-theme="dark"] .ql-snow .ql-toolbar button.ql-active .ql-fill {
    fill: var(--text-color);
}

.ql-editor {
    font-family: inherit;
    font-size: 14px;
    line-height: 1.6;
}
"""

with open('d:/new projects/notes commands and queries/static/index.css', 'a', encoding='utf-8') as f:
    f.write(css_content)

print("Quill styles appended successfully.")
