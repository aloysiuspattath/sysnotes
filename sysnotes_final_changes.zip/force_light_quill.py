import os
import re

with open('d:/new projects/notes commands and queries/static/index.css', 'r', encoding='utf-8') as f:
    text = f.read()

# Try to find block starting with /* Quill Dark Mode Overrides */ or /* Bulletproof CSS
# We'll just regex everything from /* Quill Dark Mode Overrides */ to the end of file
old_block = re.search(r'/\* Quill Dark Mode Overrides \*/.*', text, re.DOTALL)
if old_block:
    new_block = """/* Quill Dark Mode Overrides */
/* The user requested the editor to ALWAYS be light themed to avoid dark mode icon issues. */
[data-theme="dark"] .ql-toolbar.ql-snow {
    background-color: #f8f9fa !important;
    border-color: #cccccc !important;
}
[data-theme="dark"] .ql-container.ql-snow {
    background-color: #ffffff !important;
    border-color: #cccccc !important;
    color: #333333 !important;
}

/* Force Quill icons back to default dark color in case they somehow got inverted */
[data-theme="dark"] .ql-toolbar button svg {
    filter: none !important;
}
[data-theme="dark"] .ql-toolbar .ql-stroke {
    stroke: #444444 !important;
}
[data-theme="dark"] .ql-toolbar .ql-fill,
[data-theme="dark"] .ql-toolbar .ql-stroke.ql-fill {
    fill: #444444 !important;
}
[data-theme="dark"] .ql-toolbar .ql-picker {
    color: #444444 !important;
}
[data-theme="dark"] .ql-toolbar .ql-picker-options {
    background-color: #ffffff !important;
    border-color: #cccccc !important;
    color: #444444 !important;
}
[data-theme="dark"] .ql-toolbar .ql-picker-item {
    color: #444444 !important;
}

[data-theme="dark"] .ql-toolbar button:hover .ql-stroke,
[data-theme="dark"] .ql-toolbar button.ql-active .ql-stroke {
    stroke: #06c !important; /* Quill default active blue */
}
[data-theme="dark"] .ql-toolbar button:hover .ql-fill,
[data-theme="dark"] .ql-toolbar button.ql-active .ql-fill {
    fill: #06c !important;
}
[data-theme="dark"] .ql-toolbar .ql-picker-item:hover,
[data-theme="dark"] .ql-toolbar .ql-picker-label:hover {
    color: #06c !important;
}

.ql-editor {
    font-family: inherit;
    font-size: 14px;
    line-height: 1.6;
}
"""
    text = text[:old_block.start()] + new_block
    with open('d:/new projects/notes commands and queries/static/index.css', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Quill CSS updated successfully.")
else:
    print("Could not find existing Quill CSS block.")
