import os

path = 'd:/new projects/notes commands and queries/templates/index.html'
with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

add_modal_idx = -1
edit_modal_idx = -1

for i, line in enumerate(lines):
    if '<!-- ADD NOTE MODAL' in line and add_modal_idx == -1:
        add_modal_idx = i
    if '<!-- EDIT NOTE MODAL' in line and edit_modal_idx == -1:
        edit_modal_idx = i

end_idx = -1
if edit_modal_idx != -1:
    for i in range(edit_modal_idx, len(lines)):
        if '</form>' in lines[i]:
            if i + 2 < len(lines) and '</div>' in lines[i+1] and '</div>' in lines[i+2]:
                end_idx = i + 2
                break

if end_idx != -1:
    cleaned = lines[:end_idx+1]
    cleaned.extend([
        '\n\n',
        '    <!-- ═══════════════════════════════════════ -->\n',
        '    <!-- TOAST CONTAINER                         -->\n',
        '    <!-- ═══════════════════════════════════════ -->\n',
        '    <div id="toast-container" class="toast-container"></div>\n',
        '\n\n',
        '    <script src="/static/app.js?v=10"></script>\n',
        '</body>\n',
        '</html>\n'
    ])
    with open(path, 'w', encoding='utf-8') as f:
        f.writelines(cleaned)
    print(f'Fixed index.html! New length: {len(cleaned)}')
else:
    print('Could not find end of edit-note-modal')
