import urllib.request, ssl, json, jwt, datetime

key=open('.secret_key').read().strip()
token=jwt.encode({'sub': 1, 'username': 'admin', 'role': 'admin', 'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=1)}, key, algorithm='HS256')

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

note_data = json.dumps({
    'title': 'Test Add Note',
    'note_type': 'command',
    'command': 'echo "test"',
    'description': '',
    'category_id': None,
    'tags': [],
    'reference_links': []
}).encode('utf-8')

req = urllib.request.Request(
    'https://127.0.0.1:5005/api/notes',
    data=note_data,
    headers={'Content-Type': 'application/json', 'Authorization': f'Bearer {token}'}
)
try:
    res = urllib.request.urlopen(req, context=ctx)
    print("Add Note Response:")
    print(res.read().decode('utf-8'))
except Exception as e:
    print(f"Add Note Failed: {e}")
    if hasattr(e, 'read'): print(e.read().decode())
