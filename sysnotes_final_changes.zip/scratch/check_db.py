import sqlite3
conn = sqlite3.connect('sysadmin_notes.db')
cursor = conn.cursor()
cursor.execute("SELECT value FROM settings WHERE key='reverse_proxy_url'")
print(cursor.fetchone())
conn.close()
