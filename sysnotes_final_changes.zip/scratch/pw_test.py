import asyncio
from playwright.async_api import async_playwright
import traceback

async def run():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(ignore_https_errors=True)
        page = await context.new_page()

        # Listen for console logs
        page.on("console", lambda msg: print(f"CONSOLE: {msg.text}"))
        
        # Listen for network errors or non-200 responses
        page.on("response", lambda response: print(f"RESPONSE: {response.url} - {response.status}") if response.status >= 400 else None)
        page.on("requestfailed", lambda request: print(f"REQUEST FAILED: {request.url} - {request.failure}"))

        try:
            print("Navigating to login page...")
            await page.goto("https://127.0.0.1:5005/")
            
            # Wait for app to load
            await page.wait_for_timeout(2000)
            
            # If login modal is open, or we need to click login
            if await page.locator("#login-btn").is_visible():
                print("Clicking login button...")
                await page.click("#login-btn")
                await page.wait_for_timeout(1000)
            
            if await page.locator("#login-modal").is_visible():
                print("Filling login form...")
                await page.fill("#login-username", "admin")
                await page.fill("#login-password", "admin")
                await page.click("#login-form button[type='submit']")
                await page.wait_for_timeout(2000)
                print("Login submitted.")

            # Click Add Note
            print("Clicking Add Note button...")
            await page.click("#header-add-note-btn")
            await page.wait_for_timeout(1000)
            
            print("Filling Add Note form...")
            await page.fill("#add-note-title", "Playwright Test Note")
            await page.fill("#add-note-command", "echo 'playwright'")
            
            print("Submitting Add Note form...")
            await page.click("#add-note-form button[type='submit']")
            
            # Wait a bit to see if toast appears or network fails
            await page.wait_for_timeout(3000)
            
            # Check for toasts
            toasts = await page.locator(".toast").all_inner_texts()
            print("TOASTS:")
            for t in toasts:
                print(f"  - {t}")
                
        except Exception as e:
            print("Error during playwright run:")
            traceback.print_exc()
        finally:
            await browser.close()

asyncio.run(run())
