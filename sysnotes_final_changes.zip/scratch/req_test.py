import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

session = requests.Session()
session.verify = False

print("Logging in...")
res = session.post('https://127.0.0.1:5005/api/login', json={
    'username': 'admin',
    'password': 'admin',
    'login_type': 'local'
})
print(res.status_code, res.text)
if res.status_code != 200:
    exit(1)

token = res.json()['token']
session.headers.update({'Authorization': f'Bearer {token}'})

print("Adding note...")
res = session.post('https://127.0.0.1:5005/api/notes', json={
    'title': 'Test Note from Requests',
    'note_type': 'command',
    'command': 'ls -la',
    'description': '',
    'category_id': None,
    'tags': [],
    'reference_links': []
})
print(res.status_code, res.text)
