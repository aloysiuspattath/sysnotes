import json
from app import app, get_db
from auth import generate_token

app.config['TESTING'] = True
client = app.test_client()

with app.app_context():
    # Find a user to impersonate
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, role FROM users LIMIT 1")
    user = cursor.fetchone()
    conn.close()

    token = generate_token(user['id'], user['username'], user['role'])

    # Test adding a note
    payload = {
        'title': 'Test Add Note Local',
        'note_type': 'command',
        'command': 'echo "test"',
        'description': '',
        'category_id': None,
        'tags': [],
        'reference_links': []
    }

    res = client.post('/api/notes', data=json.dumps(payload), headers={
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {token}'
    })

    print(f"Status Code: {res.status_code}")
    print(f"Response: {res.data.decode('utf-8')}")
