import os
import zipfile

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        # Exclude specific directories
        dirs[:] = [d for d in dirs if d not in ('node_modules', 'venv', '.git', '__pycache__', '.pytest_cache')]
        for file in files:
            if file.endswith('.zip'): continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, path)
            ziph.write(file_path, arcname)

if __name__ == '__main__':
    project_dir = r"d:\new projects\notes commands and queries"
    zip_path = r"d:\new projects\sysnotes_backup_fast.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipdir(project_dir, zipf)
    print("Done zipping.")
