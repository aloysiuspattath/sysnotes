import os

path = 'd:/new projects/notes commands and queries/templates/index.html'
with open(path, 'r', encoding='utf-8') as f:
    text = f.read()

# First, extract the block to move
block_to_remove = """                <!-- Plain Note section -->
                <div id="edit-plain-section" style="display:none;">
                    <div class="form-group">
                        <label for="edit-note-plain" class="form-label">Note Content (Markdown supported)</label>
                        <textarea id="edit-note-plain" class="form-input form-textarea" placeholder="Write your note here..."></textarea>
                    </div>
                </div>

"""

if block_to_remove in text:
    # Remove it from its current location
    text = text.replace(block_to_remove, '', 1)
    
    # The edit-note-modal has its own <!-- Procedure steps section -->
    # We want to insert the block BEFORE the last <!-- Procedure steps section -->
    # Since there's one in add-note-modal and one in edit-note-modal,
    # rfind or simply replacing the last occurrence is safest.
    
    parts = text.rsplit('                <!-- Procedure steps section -->', 1)
    if len(parts) == 2:
        text = parts[0] + block_to_remove + '                <!-- Procedure steps section -->' + parts[1]
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(text)
        print('Moved edit-plain-section to edit-note-modal successfully.')
    else:
        print('Error: Could not find <!-- Procedure steps section --> for edit modal.')
else:
    print('Error: block_to_remove not found in text.')
