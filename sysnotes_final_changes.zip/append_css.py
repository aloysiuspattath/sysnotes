import os

css_content = """
/* EasyMDE Dark Mode Overrides */
[data-theme="dark"] .EasyMDEContainer .editor-toolbar {
    background-color: var(--card-bg);
    border-color: var(--border-color);
    color: var(--text-muted);
}
[data-theme="dark"] .EasyMDEContainer .editor-toolbar button {
    color: var(--text-muted);
}
[data-theme="dark"] .EasyMDEContainer .editor-toolbar button:hover,
[data-theme="dark"] .EasyMDEContainer .editor-toolbar button.active {
    background-color: var(--card-bg-hover);
    color: var(--text-color);
    border-color: var(--border-color);
}
[data-theme="dark"] .EasyMDEContainer .editor-toolbar i.separator {
    border-left-color: var(--border-color);
    border-right-color: transparent;
}
[data-theme="dark"] .EasyMDEContainer .CodeMirror {
    background-color: var(--input-bg);
    color: var(--text-color);
    border-color: var(--border-color);
}
[data-theme="dark"] .EasyMDEContainer .CodeMirror-cursor {
    border-left-color: var(--text-color);
}
[data-theme="dark"] .EasyMDEContainer .editor-preview {
    background-color: var(--card-bg);
    color: var(--text-color);
}
[data-theme="dark"] .EasyMDEContainer .editor-statusbar {
    color: var(--text-muted);
}
[data-theme="dark"] .EasyMDEContainer .CodeMirror-selected {
    background-color: rgba(255, 255, 255, 0.1);
}
[data-theme="dark"] .EasyMDEContainer .CodeMirror-line::selection,
[data-theme="dark"] .EasyMDEContainer .CodeMirror-line>span::selection,
[data-theme="dark"] .EasyMDEContainer .CodeMirror-line>span>span::selection {
    background-color: rgba(255, 255, 255, 0.1);
}
"""

with open('d:/new projects/notes commands and queries/static/index.css', 'a', encoding='utf-8') as f:
    f.write(css_content)

print("Styles appended successfully.")
