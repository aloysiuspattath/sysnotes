import os
import re

with open('d:/new projects/notes commands and queries/static/index.css', 'r', encoding='utf-8') as f:
    text = f.read()

old_block = re.search(r'/\* Quill Dark Mode Overrides \*/.*', text, re.DOTALL)
if old_block:
    new_block = """/* Quill Dark Mode Overrides */
[data-theme="dark"] .ql-toolbar.ql-snow {
    border-color: var(--border-color);
    background-color: var(--card-bg);
}
[data-theme="dark"] .ql-container.ql-snow {
    border-color: var(--border-color);
    background-color: var(--input-bg);
    color: var(--text-color);
}
[data-theme="dark"] .ql-snow .ql-toolbar button svg .ql-stroke,
[data-theme="dark"] .ql-toolbar.ql-snow button svg .ql-stroke,
[data-theme="dark"] .ql-snow .ql-picker svg .ql-stroke,
[data-theme="dark"] .ql-snow .ql-picker-label {
    stroke: var(--text-color) !important;
    color: var(--text-color) !important;
}
[data-theme="dark"] .ql-snow .ql-toolbar button svg .ql-fill,
[data-theme="dark"] .ql-toolbar.ql-snow button svg .ql-fill,
[data-theme="dark"] .ql-snow .ql-picker svg .ql-fill,
[data-theme="dark"] .ql-snow .ql-toolbar button svg .ql-stroke.ql-fill {
    fill: var(--text-color) !important;
}
[data-theme="dark"] .ql-snow .ql-picker-options {
    background-color: var(--card-bg);
    border-color: var(--border-color);
    color: var(--text-color);
}
[data-theme="dark"] .ql-snow .ql-picker-item,
[data-theme="dark"] .ql-snow .ql-picker-label {
    color: var(--text-color);
}
[data-theme="dark"] .ql-snow .ql-picker-item:hover,
[data-theme="dark"] .ql-snow .ql-picker-label:hover {
    color: var(--primary) !important;
}
[data-theme="dark"] .ql-snow.ql-toolbar button:hover svg .ql-stroke,
[data-theme="dark"] .ql-snow .ql-toolbar button:hover svg .ql-stroke,
[data-theme="dark"] .ql-snow.ql-toolbar button.ql-active svg .ql-stroke,
[data-theme="dark"] .ql-snow .ql-toolbar button.ql-active svg .ql-stroke,
[data-theme="dark"] .ql-snow .ql-picker-label.ql-active svg .ql-stroke {
    stroke: var(--primary) !important;
}
[data-theme="dark"] .ql-snow.ql-toolbar button:hover svg .ql-fill,
[data-theme="dark"] .ql-snow .ql-toolbar button:hover svg .ql-fill,
[data-theme="dark"] .ql-snow.ql-toolbar button.ql-active svg .ql-fill,
[data-theme="dark"] .ql-snow .ql-toolbar button.ql-active svg .ql-fill,
[data-theme="dark"] .ql-snow .ql-picker-label.ql-active svg .ql-fill {
    fill: var(--primary) !important;
}
.ql-editor {
    font-family: inherit;
    font-size: 14px;
    line-height: 1.6;
}
"""
    text = text[:old_block.start()] + new_block
    with open('d:/new projects/notes commands and queries/static/index.css', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Quill CSS updated successfully.")
else:
    print("Could not find existing Quill CSS block.")
