import os
import re

with open('d:/new projects/notes commands and queries/static/index.css', 'r', encoding='utf-8') as f:
    text = f.read()

old_block = re.search(r'/\* Quill Dark Mode Overrides \*/.*', text, re.DOTALL)
if old_block:
    new_block = """/* Quill Dark Mode Overrides */
[data-theme="dark"] .ql-toolbar.ql-snow {
    border-color: var(--border-color) !important;
    background-color: var(--card-bg) !important;
}
[data-theme="dark"] .ql-container.ql-snow {
    border-color: var(--border-color) !important;
    background-color: var(--input-bg) !important;
    color: var(--text-color) !important;
}

/* Bulletproof CSS: Invert the SVGs and force stroke to white */
[data-theme="dark"] .ql-toolbar button svg {
    filter: invert(1) brightness(2) !important;
}
[data-theme="dark"] .ql-toolbar .ql-stroke {
    stroke: #ffffff !important;
}
[data-theme="dark"] .ql-toolbar .ql-fill,
[data-theme="dark"] .ql-toolbar .ql-stroke.ql-fill {
    fill: #ffffff !important;
}

[data-theme="dark"] .ql-toolbar .ql-picker {
    color: var(--text-color) !important;
}
[data-theme="dark"] .ql-toolbar .ql-picker-options {
    background-color: var(--card-bg) !important;
    border-color: var(--border-color) !important;
    color: var(--text-color) !important;
}
[data-theme="dark"] .ql-toolbar .ql-picker-item {
    color: var(--text-color) !important;
}

/* Hover and Active states */
[data-theme="dark"] .ql-toolbar button:hover svg,
[data-theme="dark"] .ql-toolbar button.ql-active svg,
[data-theme="dark"] .ql-toolbar .ql-picker-label:hover,
[data-theme="dark"] .ql-toolbar .ql-picker-label.ql-active {
    filter: sepia(1) hue-rotate(200deg) saturate(5) brightness(1.5) !important;
}
[data-theme="dark"] .ql-toolbar .ql-picker-item:hover,
[data-theme="dark"] .ql-toolbar .ql-picker-label:hover {
    color: var(--primary) !important;
}

.ql-editor {
    font-family: inherit;
    font-size: 14px;
    line-height: 1.6;
}
"""
    text = text[:old_block.start()] + new_block
    with open('d:/new projects/notes commands and queries/static/index.css', 'w', encoding='utf-8') as f:
        f.write(text)
    print("Quill CSS updated successfully.")
else:
    print("Could not find existing Quill CSS block.")
