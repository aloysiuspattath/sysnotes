import os

path = 'd:/new projects/notes commands and queries/static/app.js'
with open(path, 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add globals
if 'let easymdeAdd = null;' not in text:
    text = text.replace('let currentUsername = null;', 'let currentUsername = null;\n    let easymdeAdd = null;\n    let easymdeEdit = null;')

# 2. Update setNoteType logic (it's inside setupNoteToggles or setNoteType function)
# I'll just find the setNoteType function and replace its body
new_set_note_type = """    function setNoteType(prefix, type) {
        const typeHidden = document.getElementById(`${prefix}-note-type`);
        const commandSection = document.getElementById(`${prefix}-command-section`);
        const stepsSection = document.getElementById(`${prefix}-steps-section`);
        const plainSection = document.getElementById(`${prefix}-plain-section`);
        typeHidden.value = type;
        document.querySelectorAll(`#${prefix}-type-command, #${prefix}-type-procedure, #${prefix}-type-plain`).forEach(b => {
            b.classList.toggle('active', b.dataset.type === type);
        });
        if (commandSection) commandSection.style.display = type === 'command' ? '' : 'none';
        if (stepsSection) stepsSection.style.display = type === 'procedure' ? '' : 'none';
        if (plainSection) plainSection.style.display = type === 'plain' ? '' : 'none';
        
        if (type === 'plain') {
            setTimeout(() => {
                if (prefix === 'add' && easymdeAdd) easymdeAdd.codemirror.refresh();
                if (prefix === 'edit' && easymdeEdit) easymdeEdit.codemirror.refresh();
            }, 10);
        }
    }"""

import re
text = re.sub(r'function setNoteType\(prefix, type\)\s*\{.*?\}\n', new_set_note_type + '\n', text, flags=re.DOTALL)

# Also update setupNoteTypeToggles initialization loop
text = text.replace('`#${prefix}-type-command, #${prefix}-type-procedure`', '`#${prefix}-type-command, #${prefix}-type-procedure, #${prefix}-type-plain`')


# 3. Handle Add Submit
add_submit_patch = """            if (type === 'command' && !command) { showToast('Command is required', true); return; }
            if (type === 'procedure' && steps.length === 0) { showToast('At least one step is required', true); return; }
            if (type === 'plain') {
                if (easymdeAdd) description = easymdeAdd.value();
                else description = document.getElementById('add-note-plain').value;
                if (!description.trim()) { showToast('Note content is required', true); return; }
            }"""
text = text.replace("            if (type === 'command' && !command) { showToast('Command is required', true); return; }\n            if (type === 'procedure' && steps.length === 0) { showToast('At least one step is required', true); return; }", add_submit_patch)

# 4. Handle Edit Submit
edit_submit_patch = """            if (type === 'command' && !command) { showToast('Command is required', true); return; }
            if (type === 'procedure' && steps.length === 0) { showToast('At least one step is required', true); return; }
            if (type === 'plain') {
                if (easymdeEdit) description = easymdeEdit.value();
                else description = document.getElementById('edit-note-plain').value;
                if (!description.trim()) { showToast('Note content is required', true); return; }
            }"""
text = text.replace("            if (type === 'command' && !command) { showToast('Command is required', true); return; }\n            if (type === 'procedure' && steps.length === 0) { showToast('At least one step is required', true); return; }", edit_submit_patch)


# 5. Populate Edit modal
edit_populate_patch = """        document.getElementById('edit-note-description').value = note.description || '';
        
        if (easymdeEdit) {
            easymdeEdit.value(note.note_type === 'plain' ? (note.description || '') : '');
        }"""
text = text.replace("        document.getElementById('edit-note-description').value = note.description || '';", edit_populate_patch)

# 6. Render Notes
render_patch = """        } else if (note.note_type === 'plain') {
            let renderedHtml = typeof marked !== 'undefined' ? DOMPurify.sanitize(marked.parse(note.description || '')) : escapeHTML(note.description || '');
            const typeBadgePlain = `<span class="note-type-badge type-procedure">${ICONS.copy} Plain Note</span>`;
            html += `<div class="note-item note-type-plain" style="animation-delay:${delay}s" data-note-id="${note.id}">
                    <div style="width:100%;">
                        <div class="note-header">
                            <div>
                                ${typeBadgePlain}
                                <a href="/note/${note.id}" target="_blank" class="note-title-link"><h3 class="note-title">${escapeHTML(note.title)}</h3></a>
                            </div>
                            ${actions}
                        </div>
                        <div class="markdown-body" style="padding:1rem 0; font-size:14px; line-height:1.6;">${renderedHtml}</div>
                        ${tagsHtml}
                    </div>
                </div>`;
        } else {"""
text = text.replace("        } else {", render_patch)

# 7. Add Initialize logic to DOMContentLoaded
init_patch = """    document.addEventListener('DOMContentLoaded', () => {
        if (typeof EasyMDE !== 'undefined') {
            easymdeAdd = new EasyMDE({ element: document.getElementById('add-note-plain'), spellChecker: false, status: false });
            easymdeEdit = new EasyMDE({ element: document.getElementById('edit-note-plain'), spellChecker: false, status: false });
        }
"""
text = text.replace("    document.addEventListener('DOMContentLoaded', () => {", init_patch)


with open(path, 'w', encoding='utf-8') as f:
    f.write(text)

print('Updated app.js successfully.')
