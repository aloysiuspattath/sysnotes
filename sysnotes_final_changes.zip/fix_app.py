import os

path = 'd:/new projects/notes commands and queries/static/app.js'
with open(path, 'r', encoding='utf-8') as f:
    text = f.read()

# The render patch string from patch_app.py
render_patch = """        } else if (note.note_type === 'plain') {
            let renderedHtml = typeof marked !== 'undefined' ? DOMPurify.sanitize(marked.parse(note.description || '')) : escapeHTML(note.description || '');
            const typeBadgePlain = `<span class="note-type-badge type-procedure">${ICONS.copy} Plain Note</span>`;
            html += `<div class="note-item note-type-plain" style="animation-delay:${delay}s" data-note-id="${note.id}">
                    <div style="width:100%;">
                        <div class="note-header">
                            <div>
                                ${typeBadgePlain}
                                <a href="/note/${note.id}" target="_blank" class="note-title-link"><h3 class="note-title">${escapeHTML(note.title)}</h3></a>
                            </div>
                            ${actions}
                        </div>
                        <div class="markdown-body" style="padding:1rem 0; font-size:14px; line-height:1.6;">${renderedHtml}</div>
                        ${tagsHtml}
                    </div>
                </div>`;
        } else {"""

# Replace all occurrences of render_patch with "        } else {"
text = text.replace(render_patch, "        } else {")

# Now carefully insert the render_patch ONLY in the renderNotes function.
# Look for:
#         if (isProcedure) {
#             // ...
#         } else {
#             // Render command note summary
#             html += `<div class="note-item note-type-command"
# We want to replace the `} else {` that comes right before `// Render command note summary`

target = "        } else {\n            // Render command note summary"
if target in text:
    text = text.replace(target, render_patch + "\n            // Render command note summary", 1)

# Also fix DOMPurify safely
text = text.replace(
    "typeof marked !== 'undefined' ? DOMPurify.sanitize", 
    "typeof marked !== 'undefined' && typeof DOMPurify !== 'undefined' ? DOMPurify.sanitize"
)

with open(path, 'w', encoding='utf-8') as f:
    f.write(text)
print('Fixed app.js')
