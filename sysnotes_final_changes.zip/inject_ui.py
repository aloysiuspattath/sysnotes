import os

path = 'd:/new projects/notes commands and queries/templates/index.html'
with open(path, 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add Plain Note button to add-note-modal
add_btn = """                    <button type="button" class="note-type-btn" data-type="plain" id="add-type-plain">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        Plain Note
                    </button>
                </div>"""

text = text.replace('Procedure / Runbook\n                    </button>\n                </div>', 'Procedure / Runbook\n                    </button>\n' + add_btn, 1)

# 2. Add Plain Note button to edit-note-modal
edit_btn = add_btn.replace('add-type-plain', 'edit-type-plain')
# The second occurrence of the pattern is in the edit modal
text = text.replace('Procedure / Runbook\n                    </button>\n                </div>', 'Procedure / Runbook\n                    </button>\n' + edit_btn, 1)


# 3. Add Plain Note section to add-note-modal
add_plain_section = """                <!-- Plain Note section -->
                <div id="add-plain-section" style="display:none;">
                    <div class="form-group">
                        <label for="add-note-plain" class="form-label">Note Content (Markdown supported)</label>
                        <textarea id="add-note-plain" class="form-input form-textarea" placeholder="Write your note here..."></textarea>
                    </div>
                </div>

"""
# Insert before <!-- Procedure steps section -->
text = text.replace('                <!-- Procedure steps section -->', add_plain_section + '                <!-- Procedure steps section -->', 1)


# 4. Add Plain Note section to edit-note-modal
edit_plain_section = add_plain_section.replace('add-plain-section', 'edit-plain-section').replace('add-note-plain', 'edit-note-plain')
text = text.replace('                <!-- Procedure steps section -->', edit_plain_section + '                <!-- Procedure steps section -->', 1)

with open(path, 'w', encoding='utf-8') as f:
    f.write(text)

print('Injected plain note UI successfully.')
